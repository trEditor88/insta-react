const $ = id => document.getElementById(id);
const DEF = { targets: '', emoji: '❤️', mix: null, dmin: 3, dmax: 8, cap: 20, hfrom: 0, hto: 24, skipQ: false, on: false };
const EMOJIS = ['❤️', '😂', '👍', '😮', '😢', '🔥'];
let cfg = { ...DEF };
const esc = s => s.replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
// mix = [{ e: 이모지, p: 확률(%) }]. 예전 설정(emoji 하나)은 그 이모지 100% 로 옮김. emoji 는 첫 칸을 계속 적어 둠(옛 코드 호환)
const fixMix = c => { if (!Array.isArray(c.mix) || !c.mix.length) c.mix = [{ e: c.emoji || '❤️', p: 100 }]; return c; };
const save = () => { cfg.emoji = cfg.mix[0].e; chrome.storage.local.set({ cfg }); };
const same = (a, b) => a.replace(/[︎️‍]/g, '') === b.replace(/[︎️‍]/g, '');   // ❤ 와 ❤️ 를 같은 이모지로
const mixSum = () => cfg.mix.reduce((a, x) => a + (+x.p || 0), 0);

$('emojis').innerHTML = EMOJIS.map(e => `<button type="button" data-e="${e}" aria-pressed="false">${e}</button>`).join('');
function addEmoji(e) {
  const i = cfg.mix.findIndex(x => same(x.e, e));
  if (i < 0) { cfg.mix.push({ e, p: Math.max(0, 100 - mixSum()) }); save(); paint(); }
  const inp = $('mix').querySelector(`input[data-i="${i < 0 ? cfg.mix.length - 1 : i}"]`);
  if (inp) { inp.focus(); inp.select(); }
}
$('emojis').onclick = e => { const b = e.target.closest('button'); if (b) addEmoji(b.dataset.e); };
$('mix').oninput = e => {
  const i = +e.target.dataset.i; if (!cfg.mix[i]) return;
  cfg.mix[i].p = Math.min(100, Math.max(0, Math.round(+e.target.value || 0))); save(); paintBars();
};
$('mix').addEventListener('change', e => { const i = +e.target.dataset.i; if (cfg.mix[i]) e.target.value = cfg.mix[i].p; });   // 150·2.5 같은 값은 칸에도 고쳐 보이기
$('mix').onclick = e => {
  const b = e.target.closest('button[data-del]'); if (!b || cfg.mix.length < 2) return;
  cfg.mix.splice(+b.dataset.del, 1); save(); paint();
};
const ONE_EMOJI = /^\p{Extended_Pictographic}(️|‍\p{Extended_Pictographic}️?|[\u{1F3FB}-\u{1F3FF}])*$/u;   // 이모지 한 글자만
$('emojiCustom').onkeydown = e => {
  if (e.key !== 'Enter') return;
  const v = $('emojiCustom').value.trim();
  if (!v) return;
  if (!ONE_EMOJI.test(v)) { $('emojiCustom').setCustomValidity('이모지 한 글자만 넣어 주세요'); $('emojiCustom').reportValidity(); return; }
  $('emojiCustom').setCustomValidity(''); $('emojiCustom').value = ''; addEmoji(v);
};
$('emojiCustom').oninput = () => $('emojiCustom').setCustomValidity('');

[['targets', 's'], ['dmin', 'n'], ['dmax', 'n'], ['cap', 'n'], ['hfrom', 'n'], ['hto', 'n'], ['skipQ', 'b'], ['on', 'b']].forEach(([k, t]) => {
  const el = $(k);
  el.oninput = () => { cfg[k] = t === 'b' ? el.checked : t === 'n' ? Math.max(0, +el.value || 0) : el.value; save(); };
});

function paint() {
  $('mix').innerHTML = cfg.mix.map((x, i) => `<div class="mixrow"><span class="e">${esc(x.e)}</span>
    <input type="number" min="0" max="100" step="1" data-i="${i}" value="${x.p}" aria-label="${esc(x.e)} 확률(%)"><span>%</span>
    <span class="bar"><i></i></span><button type="button" class="x" data-del="${i}" aria-label="${esc(x.e)} 빼기"${cfg.mix.length < 2 ? ' disabled' : ''}>✕</button></div>`).join('');
  document.querySelectorAll('#emojis button').forEach(b => b.setAttribute('aria-pressed', cfg.mix.some(x => same(x.e, b.dataset.e))));
  paintBars();
}
function paintBars() {   // 입력 중에도 칸을 다시 그리지 않고 막대·합계만 갱신(커서 유지)
  const sum = mixSum();
  $('mix').querySelectorAll('.bar i').forEach((el, i) => { el.style.width = sum ? (cfg.mix[i].p / sum * 100) + '%' : '0'; });
  $('mixSum').textContent = sum === 100 ? '합계 100%' : sum > 0 ? `합계 ${sum}% — 100이 아니어도 적은 숫자의 비율대로 나눠서 고릅니다.` : '확률을 1 이상 넣어 주세요. 모두 0이면 첫 이모지만 씁니다.';
  $('mixSum').className = 'hint' + (sum === 100 ? '' : ' warnTxt');
}
async function paintSt() {
  const { st } = await chrome.storage.local.get('st');
  const s = Object.assign({ day: '', count: 0, ok: 0, skip: 0, log: [] }, st);
  const count = s.day === new Date().toLocaleDateString('sv') ? s.count : 0;
  $('sOk').textContent = s.ok; $('sSkip').textContent = s.skip; $('sLeft').textContent = Math.max(0, cfg.cap - count);
  $('log').innerHTML = s.log.map(l => `<li class="${l.k}">${l.time} ${esc(l.t)}</li>`).join('') || '<li class="skip">기록 없음</li>';
}

chrome.storage.local.get('cfg', v => {
  cfg = fixMix({ ...DEF, ...(v.cfg || {}) });
  ['targets', 'dmin', 'dmax', 'cap', 'hfrom', 'hto'].forEach(k => $(k).value = cfg[k]);
  $('skipQ').checked = cfg.skipQ; $('on').checked = cfg.on;
  paint(); paintSt();
});
chrome.storage.onChanged.addListener(c => { if (c.st) paintSt(); });

$('clear').onclick = async () => {   // 기록만 비움(오늘 횟수·중복 방지 목록은 유지)
  const { st } = await chrome.storage.local.get('st');
  const s = Object.assign({ day: '', count: 0, ok: 0, skip: 0, done: [], log: [] }, st);
  s.log = []; s.ok = 0; s.skip = 0;
  await chrome.storage.local.set({ st: s }); paintSt();
};
$('probeBtn').onclick = async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  chrome.tabs.sendMessage(tab.id, { type: 'probe' }, r => {
    if (chrome.runtime.lastError || !r) { $('probe').textContent = '인스타그램 탭에서 열어 주세요(탭을 새로고침한 뒤 다시).'; return; }
    $('probe').textContent = r.thread
      ? `대화방: 예 · 메시지 ${r.rows}개 · 내 아이디 ${r.me || '(못 읽음)'}\n마지막 상대 메시지 보낸 사람: ${r.lastSender || '(없음)'}\n대상 인식: ${r.target ? '예' : '아니오'}`
      : 'DM 대화방(/direct/t/...)이 아닙니다.';
  });
};
$('dryBtn').onclick = async () => {   // 목록의 이모지를 하나씩 선택창에서 찾아봄(누르지 않음)
  if ($('dryBtn').disabled) return;
  $('dryBtn').disabled = true;
  try { await dryRun(); } finally { $('dryBtn').disabled = false; }
};
async function dryRun() {
  $('dry').textContent = '찾는 중…';
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const ask = e => new Promise(res => chrome.tabs.sendMessage(tab.id, { type: 'dryEmoji', emoji: e }, r => res(chrome.runtime.lastError || !r ? null : r.r)));
  const STOP = { nobtn: '공감 버튼을 못 찾았어요(인스타 화면 구조가 바뀌었을 수 있음).', nomsg: '상대가 보낸 메시지가 보이지 않거나 내 아이디를 못 읽었어요.',
    stuck: '선택창이 닫히지 않았어요. 인스타 탭에서 Esc 를 눌러 주세요.', busy: '지금 공감하는 중이에요. 잠시 뒤 다시 해 주세요.' };
  const lines = [];
  for (const x of cfg.mix) {
    const r = await ask(x.e);
    if (r === null) { $('dry').textContent = '인스타그램 DM 대화방 탭에서 열어 주세요(탭을 새로고침한 뒤 다시).'; return; }
    if (STOP[r]) { lines.push(STOP[r]); break; }
    lines.push(`${x.e} ${r === 'found' ? '찾음' : r === 'notfound' ? '못 찾음 — 이 이모지는 공감에 실패합니다' : r}`);
    $('dry').textContent = lines.join('\n') + '\n찾는 중…';
  }
  $('dry').textContent = lines.join('\n');
}
