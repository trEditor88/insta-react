const $ = id => document.getElementById(id);
const DEF = { targets: '', emoji: '❤️', dmin: 3, dmax: 8, cap: 20, hfrom: 0, hto: 24, skipQ: false, on: false };
const EMOJIS = ['❤️', '😂', '👍', '😮', '😢', '🔥'];
let cfg = { ...DEF };
const esc = s => s.replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const save = () => chrome.storage.local.set({ cfg });

$('emojis').innerHTML = EMOJIS.map(e => `<button type="button" data-e="${e}" aria-pressed="false">${e}</button>`).join('');
$('emojis').onclick = e => { const b = e.target.closest('button'); if (b) { cfg.emoji = b.dataset.e; save(); paint(); } };

[['targets', 's'], ['dmin', 'n'], ['dmax', 'n'], ['cap', 'n'], ['hfrom', 'n'], ['hto', 'n'], ['skipQ', 'b'], ['on', 'b']].forEach(([k, t]) => {
  const el = $(k);
  el.oninput = () => { cfg[k] = t === 'b' ? el.checked : t === 'n' ? Math.max(0, +el.value || 0) : el.value; save(); };
});

function paint() {
  document.querySelectorAll('#emojis button').forEach(b => b.setAttribute('aria-pressed', b.dataset.e === cfg.emoji));
}
async function paintSt() {
  const { st } = await chrome.storage.local.get('st');
  const s = Object.assign({ day: '', count: 0, ok: 0, skip: 0, log: [] }, st);
  const count = s.day === new Date().toISOString().slice(0, 10) ? s.count : 0;
  $('sOk').textContent = s.ok; $('sSkip').textContent = s.skip; $('sLeft').textContent = Math.max(0, cfg.cap - count);
  $('log').innerHTML = s.log.map(l => `<li class="${l.k}">${l.time} ${esc(l.t)}</li>`).join('') || '<li class="skip">기록 없음</li>';
}

chrome.storage.local.get('cfg', v => {
  cfg = { ...DEF, ...(v.cfg || {}) };
  ['targets', 'dmin', 'dmax', 'cap', 'hfrom', 'hto'].forEach(k => $(k).value = cfg[k]);
  $('skipQ').checked = cfg.skipQ; $('on').checked = cfg.on;
  paint(); paintSt();
});
chrome.storage.onChanged.addListener(c => { if (c.st) paintSt(); });

$('clear').onclick = async () => { await chrome.storage.local.remove('st'); paintSt(); };
$('probeBtn').onclick = async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  chrome.tabs.sendMessage(tab.id, { type: 'probe' }, r => {
    if (chrome.runtime.lastError || !r) { $('probe').textContent = '인스타그램 탭에서 열어 주세요(탭을 새로고침한 뒤 다시).'; return; }
    $('probe').textContent = r.thread
      ? `대화방: 예 · 메시지 줄 ${r.rows}개\n상단 글자: ${r.header || '(못 읽음)'}\n대상 인식: ${r.target ? '예' : '아니오'}`
      : 'DM 대화방(/direct/t/...)이 아닙니다.';
  });
};
