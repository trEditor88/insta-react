const $ = id => document.getElementById(id);
const DEF = { targets: '', emoji: '❤️', dmin: 3, dmax: 8, cap: 20, hfrom: 0, hto: 24, skipQ: false, on: false };
const EMOJIS = ['❤️', '😂', '👍', '😮', '😢', '🔥'];
let cfg = { ...DEF };
const esc = s => s.replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const save = () => chrome.storage.local.set({ cfg });

$('emojis').innerHTML = EMOJIS.map(e => `<button type="button" data-e="${e}" aria-pressed="false">${e}</button>`).join('');
$('emojis').onclick = e => { const b = e.target.closest('button'); if (b) { cfg.emoji = b.dataset.e; $('emojiCustom').value = ''; save(); paint(); } };
$('emojiCustom').oninput = () => { const v = $('emojiCustom').value.trim(); if (v) { cfg.emoji = v; save(); paint(); } };

[['targets', 's'], ['dmin', 'n'], ['dmax', 'n'], ['cap', 'n'], ['hfrom', 'n'], ['hto', 'n'], ['skipQ', 'b'], ['on', 'b']].forEach(([k, t]) => {
  const el = $(k);
  el.oninput = () => { cfg[k] = t === 'b' ? el.checked : t === 'n' ? Math.max(0, +el.value || 0) : el.value; save(); };
});

function paint() {
  document.querySelectorAll('#emojis button').forEach(b => b.setAttribute('aria-pressed', b.dataset.e === cfg.emoji));
}
async function paintSt() {
  const { st } = await chrome.storage.local.get('st');
  const s = Object.assign({ day: '', count: 0, ok: 0, skip: 0, log: [] }, st);
  const count = s.day === new Date().toLocaleDateString('sv') ? s.count : 0;
  $('sOk').textContent = s.ok; $('sSkip').textContent = s.skip; $('sLeft').textContent = Math.max(0, cfg.cap - count);
  $('log').innerHTML = s.log.map(l => `<li class="${l.k}">${l.time} ${esc(l.t)}</li>`).join('') || '<li class="skip">기록 없음</li>';
}

chrome.storage.local.get('cfg', v => {
  cfg = { ...DEF, ...(v.cfg || {}) };
  ['targets', 'dmin', 'dmax', 'cap', 'hfrom', 'hto'].forEach(k => $(k).value = cfg[k]);
  if (!EMOJIS.includes(cfg.emoji)) $('emojiCustom').value = cfg.emoji;
  $('skipQ').checked = cfg.skipQ; $('on').checked = cfg.on;
  paint(); paintSt();
});
chrome.storage.onChanged.addListener(c => { if (c.st) paintSt(); });

$('clear').onclick = async () => { await chrome.storage.local.remove('st'); paintSt(); };
$('probeBtn').onclick = async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  chrome.tabs.sendMessage(tab.id, { type: 'probe' }, r => {
    if (chrome.runtime.lastError || !r) { $('probe').textContent = '인스타그램 탭에서 열어 주세요(탭을 새로고침한 뒤 다시).'; return; }
    $('probe').textContent = r.thread
      ? `대화방: 예 · 메시지 ${r.rows}개 · 내 아이디 ${r.me || '(못 읽음)'}\n마지막 상대 메시지 보낸 사람: ${r.lastSender || '(없음)'}\n대상 인식: ${r.target ? '예' : '아니오'}`
      : 'DM 대화방(/direct/t/...)이 아닙니다.';
  });
};
$('dryBtn').onclick = async () => {
  $('dry').textContent = '찾는 중…';
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  chrome.tabs.sendMessage(tab.id, { type: 'dryEmoji', emoji: cfg.emoji }, r => {
    if (chrome.runtime.lastError || !r) { $('dry').textContent = '인스타그램 DM 대화방 탭에서 열어 주세요(탭을 새로고침한 뒤 다시).'; return; }
    $('dry').textContent = { found: `${cfg.emoji} 를 찾았어요. 켜 두면 이 이모지로 공감합니다.`, notfound: `선택창에서 ${cfg.emoji} 를 못 찾았어요.`,
      nobtn: '공감 버튼을 못 찾았어요(인스타 화면 구조가 바뀌었을 수 있음).', nomsg: '상대가 보낸 메시지가 보이지 않거나 내 아이디를 못 읽었어요.', stuck: '선택창이 닫히지 않았어요. 인스타 탭에서 Esc 를 눌러 주세요.', busy: '지금 공감하는 중이에요. 잠시 뒤 다시 해 주세요.' }[r.r] || r.r;
  });
};
