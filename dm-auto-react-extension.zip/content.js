// DM 자동 공감 — 인스타그램 페이지 안에서 실행되는 콘텐츠 스크립트
// 2026-10 인스타 구조: 메시지마다 [role=button][aria-label="<아이디>님의 메시지에 공감하기"] 가 붙어 있고,
// 누르면 빠른 공감 6칸(사용자가 '맞춤 설정'으로 바꿀 수 있음) + "+"(전체 선택창·이모티콘 검색)가 뜬다.
// 더블클릭은 "빠른 공감 첫 칸"을 보내므로, 그 칸(하트 자리)에 다른 이모지를 넣어 둔 사람에게는 엉뚱한 공감이 간다 → 쓰지 않고
// 선택창에서 글자가 정확히 같은 이모지를 찾아 누른 뒤, 메시지에 실제로 붙었는지 확인한다.
(() => {
  const DEF = { targets: '', emoji: '❤️', dmin: 3, dmax: 8, cap: 20, hfrom: 0, hto: 24, skipQ: false, on: false };
  const DONE_MS = 10 * 60 * 1000;          // 탭 사이 중복 방지 기록 보관 시간
  let cfg = { ...DEF };
  let base = null;                         // { path, keys:Set, els:WeakSet } 대화방을 연 순간 있던 메시지(건드리지 않음)
  let pending = null;                      // 기준선 후보(두 번 연속 같아야 확정)
  let scanTimer = null, scanFirst = 0, busy = false;
  const queue = [];

  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const today = () => new Date().toLocaleDateString('sv');   // 로컬 날짜(YYYY-MM-DD)
  const hhmm = () => new Date().toTimeString().slice(0, 8);
  const isThread = () => /^\/direct\/t\/\d+/.test(location.pathname);
  const norm = s => String(s || '').replace(/[︎️‍]/g, '').trim();   // 이모지 비교: 변형 선택자 차이 무시
  const targets = () => cfg.targets.split(',').map(s => s.trim().replace(/^@+/, '').toLowerCase()).filter(t => [...t].length >= 2);
  const reEsc = s => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const inHours = () => { const h = new Date().getHours(); return cfg.hfrom < cfg.hto ? (h >= cfg.hfrom && h < cfg.hto) : (h >= cfg.hfrom || h < cfg.hto); };

  const getSt = async () => {
    const { st } = await chrome.storage.local.get('st');
    const s = Object.assign({ day: '', count: 0, ok: 0, skip: 0, done: [], log: [] }, st);
    if (s.day !== today()) { s.day = today(); s.count = 0; }
    s.done = (s.done || []).filter(d => d && d.t > Date.now() - DONE_MS);
    return s;
  };
  const putSt = s => chrome.storage.local.set({ st: s });
  async function addLog(kind, text) {
    const s = await getSt();
    s.log.unshift({ k: kind, t: text, time: hhmm() });
    s.log = s.log.slice(0, 50);
    if (kind === 'ok') s.ok++; else if (kind === 'skip') s.skip++;
    await putSt(s);
  }

  // ── 화면 읽기 ──────────────────────────────────────────
  const REACT_RE = /^(.+?)님의 메시지에 공감하기$|^React to (?:message from )?(.+?)(?:'s message)?$/i;
  const reactBtns = () => [...document.querySelectorAll('div[role="button"][aria-label]')].filter(b => REACT_RE.test(b.getAttribute('aria-label')));
  const senderOf = btn => { const m = btn.getAttribute('aria-label').match(REACT_RE); return ((m && (m[1] || m[2])) || '').trim().toLowerCase(); };
  function boxOf(btn) {                    // 버튼에서 위로 올라가며 공감 버튼이 하나뿐인 가장 큰 조상 = 이 메시지 덩어리(이웃 메시지와 섞이지 않게)
    let c = btn.parentElement, best = null;
    for (let i = 0; i < 10 && c; i++, c = c.parentElement) {
      if ([...c.querySelectorAll('div[role="button"][aria-label]')].filter(b => REACT_RE.test(b.getAttribute('aria-label'))).length > 1) break;
      best = c;
    }
    return best;
  }
  const textOf = box => { const b = box && box.querySelector('div[dir="auto"]'); return b ? b.innerText.trim() : ''; };
  // 내 아이디: ① 왼쪽 메뉴의 내 프로필 사진(alt "<아이디>님의 프로필 사진") ② 없으면 오른쪽에 붙은 말풍선의 주인
  let meCache = '';
  function myId() {
    if (meCache) return meCache;
    const img = [...document.querySelectorAll('a[href] img[alt]')].find(i => /님의 프로필 사진$|'s profile picture$/.test(i.alt) && i.getBoundingClientRect().left < 260);
    const a = img && img.closest('a[href]');
    const m = a && a.getAttribute('href').match(/^\/([\w.]+)\/?$/);
    if (m) return (meCache = m[1].toLowerCase());
    const side = {};                       // 보낸 사람별 말풍선 가운데 x 평균 → 더 오른쪽이 나
    reactBtns().forEach(b => { const box = boxOf(b), bub = box && box.querySelector('div[dir="auto"]'); if (!bub) return;
      const r = bub.getBoundingClientRect(), s = senderOf(b); (side[s] = side[s] || []).push(r.left + r.width / 2); });
    const avg = Object.entries(side).map(([s, xs]) => [s, xs.reduce((a, b) => a + b, 0) / xs.length]).sort((a, b) => b[1] - a[1]);
    return avg.length >= 2 && avg[0][1] - avg[1][1] > 100 ? avg[0][0] : '';   // 두 사람이 다 보일 때만(한쪽만 있으면 모름)
  }
  // 대화 상단(메시지 위쪽)의 이름·아이디 글자 — 대상에 '이름'을 적은 경우용
  const inMessage = e => {   // 메시지 말풍선 안인지(공감 버튼을 품은 조상이 있으면 메시지)
    let c = e;
    for (let i = 0; i < 12 && c; i++, c = c.parentElement)
      if ([...c.querySelectorAll('div[role="button"][aria-label]')].some(b => REACT_RE.test(b.getAttribute('aria-label')))) return true;
    return false;
  };
  function headerText() {
    const out = [];
    document.querySelectorAll('a[href], h1, h2, span').forEach(e => {
      const r = e.getBoundingClientRect();
      if (r.top < 0 || r.top > 150 || r.left < 300) return;
      if (e.tagName !== 'A' && e.children.length) return;
      if (inMessage(e)) return;   // 위로 스크롤돼 상단에 걸친 메시지 글자는 제목이 아님
      const t = (e.textContent || '').trim();
      if (t && t.length < 60) out.push(t.toLowerCase());
      const m = (e.getAttribute('href') || '').match(/^\/([\w.]+)\/?$/);
      if (m) out.push(m[1].toLowerCase());
    });
    return out;
  }
  // 메시지 목록(위→아래). 키 = 대화방|보낸 사람|글|같은 글 중 몇 번째
  function messages() {
    const seen = {};
    return reactBtns().map(btn => {
      const box = boxOf(btn), sender = senderOf(btn), text = textOf(box);
      const k0 = sender + '|' + text; seen[k0] = (seen[k0] || 0) + 1;
      return { btn, box, sender, text, key: location.pathname + '|' + k0 + '|' + seen[k0] };
    }).filter(m => m.box && m.sender);
  }
  function isTarget(m) {
    const me = myId();
    if (!me || m.sender === me) return false;                 // 내 아이디를 모르면 아무것도 안 함(내 메시지에 공감하는 사고 방지)
    const ts = targets();
    if (ts.includes(m.sender)) return true;                    // 아이디가 정확히 같음
    // 이름으로 적은 경우: 나 말고 보낸 사람이 한 명뿐인 1:1 대화방이고, 상단 글자 중 하나가 대상과 정확히 같을 때만(그룹 채팅 제외)
    const others = new Set(reactBtns().map(senderOf).filter(s => s && s !== me));
    if (others.size !== 1) return false;
    const head = headerText();
    return ts.some(t => head.includes(t));
  }

  // ── 공감 누르기 ────────────────────────────────────────
  const fire = (el, type) => {
    const r = el.getBoundingClientRect();
    el.dispatchEvent(new MouseEvent(type, { bubbles: true, cancelable: true, view: window, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2 }));
  };
  const press = el => ['pointerover', 'mouseover', 'pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(t => fire(el, t));
  const dialogs = () => [...document.querySelectorAll('[role="dialog"]')].filter(d => d.getBoundingClientRect().width > 0);
  async function closeAll() {              // 공감 선택창만 닫는다(Esc·닫기 버튼). 바깥 클릭은 엉뚱한 것을 누를 수 있어 안 씀. 닫혔으면 true
    for (let i = 0; i < 3 && pickers().length; i++) {
      const close = pickers().map(d => d.querySelector('[aria-label="닫기"], [aria-label="Close"]')).find(Boolean);
      if (close) press(close.closest('[role="button"], button') || close);
      [document.activeElement, document].forEach(t => t && ['keydown', 'keyup'].forEach(type =>
        t.dispatchEvent(new KeyboardEvent(type, { key: 'Escape', code: 'Escape', keyCode: 27, which: 27, bubbles: true }))));
      await sleep(300);
    }
    return !pickers().length;
  }
  async function waitFor(fn, ms) { for (let t = 0; t < ms; t += 150) { const v = fn(); if (v) return v; await sleep(150); } return null; }
  // 주어진 창들 안에서 글자가 정확히 같은 이모지 칸 찾기
  function findEmoji(emoji, wins) {
    const want = norm(emoji);
    if (!want) return null;
    for (const d of wins) {
      const hit = [...d.querySelectorAll('[role="button"], button')].find(b => b.getBoundingClientRect().width > 0 && norm(b.innerText) === want);
      if (hit) return hit;
    }
    return null;
  }
  const EMOJI_WORDS = { '❤': '하트', '😂': '기쁨의 눈물', '😮': '입 벌린', '😢': '우는', '😡': '화난', '👍': '좋아요', '🔥': '불', '😍': '하트 눈', '🥰': '하트', '👏': '박수', '🙏': '기도', '😆': '웃는', '🤣': '웃는' };
  function setInput(input, value) {        // React 가 관리하는 입력칸에 값 넣기
    const set = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;
    set.call(input, value); input.dispatchEvent(new Event('input', { bubbles: true }));
  }
  // 공감으로 붙은 이모지 수 = 메시지 덩어리 전체 - 말풍선(글) 안 이모지. 양쪽 다 norm 해서 변형 선택자(❤️ 등) 차이를 없앰
  const emojiCount = (text, emoji) => { const w = norm(emoji); return w ? (norm(text).match(new RegExp(reEsc(w), 'gu')) || []).length : 0; };
  function reactCount(box, emoji) {
    if (!box) return 0;
    let n = emojiCount(box.innerText, emoji);
    box.querySelectorAll('div[dir="auto"]').forEach(b => { n -= emojiCount(b.innerText, emoji); });   // 글 속 이모지는 공감이 아님
    return Math.max(0, n);
  }
  const isPicker = d => !!d.querySelector('svg[aria-label="이모티콘 선택"], svg[aria-label="Choose an emoji"], input[aria-label="이모티콘 검색"]')
    || [...d.querySelectorAll('[role="button"], button')].some(b => { const t = (b.innerText || '').trim(); return t && [...t].length <= 3 && /\p{Extended_Pictographic}/u.test(t); });
  const pickers = () => dialogs().filter(isPicker);   // 공감 선택창만(인스타가 띄운 다른 창은 건드리지 않음)

  // 결과: 'ok' | 'unverified' | 'already' | 'nobtn' | 'notfound' | 'stuck'(창이 안 닫힘) | 'found'(시험)
  async function react(m, emoji, dry) {
    if (!norm(emoji)) return 'notfound';
    if (pickers().length && !await closeAll()) return 'stuck';   // 남아 있는 공감 선택창이 있으면 먼저 닫고, 안 닫히면 중단
    const before = reactCount(m.box, emoji);
    if (before > 0 && !dry) return 'already';                    // 같은 공감이 이미 붙어 있으면 누르지 않음(누르면 취소될 수 있음)
    ['pointerover', 'mouseover', 'mousemove'].forEach(t => fire(m.box, t));
    await sleep(300);
    if (!m.btn.isConnected) return 'nobtn';
    const old = new Set(dialogs());
    press(m.btn);
    const mine = () => dialogs().filter(d => !old.has(d));          // 이번에 새로 뜬 창에서만 찾음
    if (!await waitFor(() => mine().length, 3000)) return 'nobtn';
    let hit = await waitFor(() => findEmoji(emoji, mine()), 1200);   // 1) 빠른 공감 6칸(사용자가 바꾼 칸 포함)에서 글자로 찾기
    if (!hit) {                                                      // 2) "+" → 전체 선택창
      const plus = mine().flatMap(d => [...d.querySelectorAll('svg[aria-label="이모티콘 선택"], svg[aria-label="Choose an emoji"], svg[aria-label="Choose emoji"]')])
        .map(s => s.closest('[role="button"], button')).find(Boolean);
      if (plus) {
        press(plus);
        hit = await waitFor(() => findEmoji(emoji, mine()), 2000);
        const search = !hit && mine().map(d => d.querySelector('input[aria-label="이모티콘 검색"], input[placeholder="이모티콘 검색"], input[type="search"]')).find(Boolean)
          || (!hit && document.querySelector('input[aria-label="이모티콘 검색"]'));
        const word = EMOJI_WORDS[norm(emoji)];
        if (search && word) { setInput(search, word); hit = await waitFor(() => findEmoji(emoji, mine()), 2000); }
        if (!hit && search) { setInput(search, ''); await sleep(500); }
        for (let i = 0; !hit && i < 60; i++) {                     // 3) 전체 목록을 내려가며 찾기(가상 스크롤). 끝에 닿으면 멈춤
          const sc = mine().flatMap(d => [...d.querySelectorAll('*')]).find(e => e.scrollHeight > e.clientHeight + 20 && /auto|scroll/.test(getComputedStyle(e).overflowY));
          if (!sc) break;
          const prev = sc.scrollTop; sc.scrollTop += sc.clientHeight * 0.8; await sleep(250);
          hit = findEmoji(emoji, mine());
          if (!hit && sc.scrollTop === prev) break;
        }
      }
    }
    if (!hit) { await closeAll(); return 'notfound'; }
    if (dry) { return await closeAll() ? 'found' : 'stuck'; }       // 시험용: 찾기만 하고 누르지 않음
    press(hit);
    await sleep(1500);
    if (dialogs().length) await closeAll();
    const box = m.box.isConnected ? m.box : (messages().find(x => x.key === m.key) || {}).box;
    return countIn(box, emoji) > before ? 'ok' : 'unverified';
  }

  // ── 판정 + 예약 ────────────────────────────────────────
  async function handle(m) {
    if (!cfg.on || !isTarget(m)) return;                           // 대상 아닌 메시지는 기록도 안 남김
    const short = `"${m.text.slice(0, 30)}"`;
    const s = await getSt();
    if (s.done.some(d => d.k === m.key)) return;                   // 다른 탭이 이미 처리
    let why = null;
    if (!inHours()) why = '활동 시간 밖';
    else if (s.count >= cfg.cap) why = '하루 한도 초과';
    else if (cfg.skipQ && /[?？]/.test(m.text)) why = '질문이라 제외';
    if (why) { await addLog('skip', `${short} → ${why}`); return; }
    s.done.push({ k: m.key, t: Date.now() }); s.done = s.done.slice(-500); await putSt(s);   // 먼저 '처리함' 표시(탭 간 중복 방지). 한도는 성공했을 때만 아래에서 셈
    const lo = Math.min(cfg.dmin, cfg.dmax), hi = Math.max(cfg.dmin, cfg.dmax);
    const path = location.pathname;
    await sleep((lo + Math.random() * (hi - lo)) * 1000);
    // 기다리는 동안 꺼졌거나·대화방을 옮겼거나·대상을 바꿨으면 취소
    const cur = location.pathname === path && cfg.on && inHours() ? messages().find(x => x.key === m.key) : null;
    if (!cur || !isTarget(cur)) { await addLog('skip', `${short} → 대기 중 상황이 바뀌어 취소`); return; }
    const emoji = cfg.emoji;
    const r = await react(cur, emoji);
    if (r === 'ok' || r === 'unverified') { const s2 = await getSt(); s2.count++; await putSt(s2); }   // 실제로 눌렀을 때만 하루 한도 소모
    const msg = { ok: `${emoji} 공감함`, unverified: `${emoji} 눌렀지만 붙었는지 확인 못 함`, already: `이미 ${emoji} 공감이 있어 건너뜀`, nobtn: '공감 버튼을 못 찾음',
      notfound: `선택창에서 ${emoji} 를 못 찾음`, stuck: '열린 창이 닫히지 않아 중단' }[r] || r;
    await addLog(r === 'ok' ? 'ok' : r === 'already' ? 'skip' : 'no', `${short} → ${msg}`);
  }

  async function pump() {                  // 공감은 한 번에 하나씩(선택창이 겹치지 않게)
    if (busy) return; busy = true;
    try {
      while (queue.length) {
        const m = queue.shift();
        try { await handle(m); }
        catch (e) { await closeAll().catch(() => {}); await addLog('no', `"${m.text.slice(0, 30)}" → 오류: ${String(e && e.message || e).slice(0, 80)}`); }
      }
    } finally { busy = false; }
  }

  function doScan() {
    if (!isThread()) { base = pending = null; queue.length = 0; return; }
    if (base && base.path !== location.pathname) { base = pending = null; queue.length = 0; }   // 대화방을 옮김: 즉시 기준선 다시
    const ms = messages();
    if (!base) {                           // 처음 보이는 기록은 "이미 본 것". 화면이 다 그려지도록 두 번 연속 같을 때 확정
      if (!ms.length) return;
      const sig = location.pathname + '#' + ms.map(m => m.key).join('\n');
      if (!pending || pending.sig !== sig) { pending = { sig }; return; }
      base = { path: location.pathname, at: Date.now(), keys: new Set(ms.map(m => m.key)), els: new WeakSet(ms.map(m => m.btn)) };
      pending = null; return;
    }
    // 새 메시지 = 기준선 이후 새로 생긴 요소이면서 처음 보는 키, 그리고 맨 아래 5개 안(위로 스크롤해 불러온 옛 메시지 제외)
    const fresh = ms.slice(-5).filter(m => !base.els.has(m.btn) && !base.keys.has(m.key));
    ms.forEach(m => { base.keys.add(m.key); base.els.add(m.btn); });
    if (Date.now() - base.at < 2500) return;   // 기준선 직후 늦게 그려지는 옛 메시지는 새 메시지가 아님(둘로 나뉘어 로드되는 경우)
    if (fresh.length >= 3) return;         // 한꺼번에 3개 이상 = 화면을 다시 그린 것으로 보고 반응하지 않음
    fresh.forEach(m => queue.push(m));
    pump();
  }
  function scan() {                        // 변화가 계속 이어져도 최대 2초 안에는 한 번 돈다
    const now = Date.now();
    if (!scanFirst) scanFirst = now;
    clearTimeout(scanTimer);
    const run = () => { scanFirst = 0; try { doScan(); } catch (e) {} };
    if (now - scanFirst > 2000) run(); else scanTimer = setTimeout(run, 700);
  }

  setInterval(scan, 1500);
  new MutationObserver(scan).observe(document.documentElement, { childList: true, subtree: true });

  // 설정 불러오기·변경 반영
  chrome.storage.local.get('cfg', v => { cfg = { ...DEF, ...(v.cfg || {}) }; });
  chrome.storage.onChanged.addListener(c => { if (c.cfg) cfg = { ...DEF, ...(c.cfg.newValue || {}) }; });

  // 팝업의 "현재 대화 인식 확인" + "이모지 찾기 시험"(누르지 않음)
  chrome.runtime.onMessage.addListener((m, _s, send) => {
    if (m.type === 'probe') {
      const ms = isThread() ? messages() : [], me = myId();
      const last = [...ms].reverse().find(x => x.sender !== me);
      send({ thread: isThread(), rows: ms.length, me, header: headerText().join(' ').slice(0, 120),
             lastSender: last ? last.sender : '', target: !!last && isTarget(last) });
      return;
    }
    if (m.type === 'dryEmoji') {
      if (busy) { send({ r: 'busy' }); return; }
      const me = myId(), last = [...messages()].reverse().find(x => x.sender !== me);
      if (!last || !me) { send({ r: 'nomsg' }); return; }
      busy = true;
      react(last, m.emoji || cfg.emoji, true).then(r => send({ r })).catch(e => send({ r: 'error: ' + String(e && e.message || e).slice(0, 80) })).finally(() => { busy = false; pump(); });
      return true;                         // 비동기 응답
    }
  });
  window.__dmReact = { messages, isTarget, react, myId, findEmoji, dialogs, reactCount };   // 시험용
})();
