// DM 자동 공감 — 인스타그램 페이지 안에서 실행되는 콘텐츠 스크립트
// 주의: 인스타그램 화면 구조에 의존하므로 구조가 바뀌면 깨질 수 있다.
(() => {
  const DEF = { targets: '', emoji: '❤️', dmin: 3, dmax: 8, cap: 20, hfrom: 0, hto: 24, skipQ: false, on: false };
  let cfg = { ...DEF };
  let seen = new WeakSet();      // 이미 본 메시지 줄(요소)
  let baselined = false;         // 처음 열었을 때 있던 기록은 건드리지 않음
  let lastPath = '';
  let scanTimer = null;

  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const today = () => new Date().toISOString().slice(0, 10);
  const hhmm = () => new Date().toTimeString().slice(0, 8);
  const isThread = () => /^\/direct\/t\/\d+/.test(location.pathname);
  const targets = () => cfg.targets.split(',').map(s => s.trim().replace(/^@/, '').toLowerCase()).filter(Boolean);

  const getSt = async () => {
    const { st } = await chrome.storage.local.get('st');
    const s = Object.assign({ day: '', count: 0, ok: 0, skip: 0, done: [], log: [] }, st);
    if (s.day !== today()) { s.day = today(); s.count = 0; }
    return s;
  };
  const putSt = s => chrome.storage.local.set({ st: s });
  async function addLog(kind, text) {
    const s = await getSt();
    s.log.unshift({ k: kind, t: text, time: hhmm() });
    s.log = s.log.slice(0, 50);
    if (kind === 'ok') s.ok++; else if (kind === 'skip') s.skip++;
    await putSt(s);
  }

  // ── 화면 읽기 ──────────────────────────────────────────
  const rows = () => [...document.querySelectorAll('div[role="row"]')].filter(r => r.querySelector('div[dir="auto"]'));
  const bubbleOf = row => row.querySelector('div[dir="auto"]');

  function column() {
    const rs = rows();
    if (!rs.length) return null;
    return rs[0].parentElement.getBoundingClientRect();
  }
  // 오른쪽 끝에 붙어 있으면 내가 보낸 메시지
  function isMine(row) {
    const col = column(); const b = bubbleOf(row).getBoundingClientRect();
    if (!col) return false;
    return b.right > col.right - col.width * 0.12;
  }
  // 대화 상단(메시지 위쪽)에 보이는 상대 이름·아이디 글자 모으기
  function headerText() {
    const col = column(); if (!col) return '';
    const out = [];
    document.querySelectorAll('a[href], h1, h2, span, div[role="button"]').forEach(e => {
      const r = e.getBoundingClientRect();
      if (r.top < 0 || r.top > 150 || r.left < col.left - 60 || r.right > col.right + 60) return;
      if (e.tagName !== 'A' && e.children.length) return;
      const t = (e.textContent || '').trim();
      if (t && t.length < 60) out.push(t);
      const m = (e.getAttribute('href') || '').match(/^\/([\w.]+)\/?$/);
      if (m) out.push(m[1]);
    });
    return out.join(' ').toLowerCase();
  }
  function isTarget() {
    const h = headerText();
    return targets().some(t => h.includes(t));
  }
  const keyOf = (row, text) => {
    const same = rows().filter(r => bubbleOf(r).innerText === text);
    return location.pathname + '|' + text + '|' + same.indexOf(row);
  };

  // ── 공감 누르기 ────────────────────────────────────────
  const fire = (el, type, extra = {}) => {
    const r = el.getBoundingClientRect();
    el.dispatchEvent(new MouseEvent(type, { bubbles: true, cancelable: true, view: window, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2, ...extra }));
  };
  async function react(row) {
    const b = bubbleOf(row);
    if (cfg.emoji === '❤️') {                       // 하트: 메시지 더블클릭이 가장 안정적
      fire(b, 'dblclick', { detail: 2 });
      return true;
    }
    ['mouseover', 'mouseenter', 'mousemove'].forEach(t => fire(row, t));   // 호버 버튼 띄우기
    await sleep(400);
    const btn = [...row.querySelectorAll('[aria-label]')].find(e => /react|반응|emoji|이모티콘/i.test(e.getAttribute('aria-label')));
    if (!btn) return false;
    fire(btn, 'click');
    await sleep(500);
    const pick = [...document.querySelectorAll('[role="button"], button, span')].find(e => e.children.length === 0 && e.textContent.trim() === cfg.emoji);
    if (!pick) return false;
    fire(pick.closest('[role="button"], button') || pick, 'click');
    return true;
  }

  // ── 판정 + 예약 ────────────────────────────────────────
  async function handle(row) {
    const text = bubbleOf(row).innerText.trim();
    if (!text) return;
    const s = await getSt();
    let why = null;
    if (!cfg.on) why = '꺼져 있음';
    else if (isMine(row)) return;                                  // 내 메시지는 기록도 안 함
    else if (!isTarget()) why = '대상이 아닌 대화';
    else {
      const key = keyOf(row, text);
      if (s.done.includes(key)) return;
      const h = new Date().getHours();
      if (h < cfg.hfrom || h >= cfg.hto) why = '활동 시간 밖';
      else if (s.count >= cfg.cap) why = '하루 한도 초과';
      else if (cfg.skipQ && /[?？]/.test(text)) why = '질문이라 제외';
      if (!why) {
        s.count++; s.done.push(key); s.done = s.done.slice(-500); await putSt(s);
        const lo = Math.min(cfg.dmin, cfg.dmax), hi = Math.max(cfg.dmin, cfg.dmax);
        await sleep((lo + Math.random() * (hi - lo)) * 1000);
        if (!row.isConnected) { await addLog('skip', `"${text}" → 대기 중 사라져 취소`); return; }
        const ok = await react(row);
        await addLog(ok ? 'ok' : 'no', `"${text}" → ${ok ? cfg.emoji + ' 공감 시도' : '공감 버튼을 못 찾음'}`);
        return;
      }
    }
    if (cfg.on) await addLog('skip', `"${text.slice(0, 30)}" → ${why}`);
  }

  function scan() {
    clearTimeout(scanTimer);
    scanTimer = setTimeout(() => {
      if (!isThread()) { baselined = false; return; }
      const rs = rows();
      if (!baselined) {                       // 처음 보이는 기록은 "이미 본 것"으로 처리
        if (!rs.length) return;
        rs.forEach(r => seen.add(r));
        baselined = true;
        return;
      }
      rs.forEach(r => { if (!seen.has(r)) { seen.add(r); handle(r); } });
    }, 700);
  }

  // 대화방이 바뀌면 기준선을 다시 잡음 (인스타그램은 주소만 바뀌는 단일 페이지)
  setInterval(() => {
    if (location.pathname !== lastPath) { lastPath = location.pathname; baselined = false; seen = new WeakSet(); }
    scan();
  }, 1500);
  new MutationObserver(scan).observe(document.documentElement, { childList: true, subtree: true });

  // 설정 불러오기·변경 반영
  chrome.storage.local.get('cfg', v => { cfg = { ...DEF, ...(v.cfg || {}) }; });
  chrome.storage.onChanged.addListener(c => { if (c.cfg) cfg = { ...DEF, ...(c.cfg.newValue || {}) }; });

  // 팝업의 "현재 대화 인식 확인"용
  chrome.runtime.onMessage.addListener((m, _s, send) => {
    if (m.type === 'probe') {
      send({ thread: isThread(), rows: rows().length, header: headerText().slice(0, 120), target: isThread() && isTarget() });
    }
  });
})();
